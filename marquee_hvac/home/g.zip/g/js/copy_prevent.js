<script type='text/javascript'>
// To prevent saving web site directly using "ctrl-s"
$(document).bind('keydown keypress', 'ctrl+s', function () {
        $('#save').click();
        return false;
    });
</script>
<script type='text/javascript'>
var isCtrl = false;
document.onkeyup=function(e)
{
if(e.which == 17)
isCtrl=false;
}
document.onkeydown=function(e)
{
if(e.which == 123)
isCtrl=true;
if (((e.which == 85) || (e.which == 65) || (e.which == 88) || (e.which == 67) || (e.which == 86) || (e.which == 2) || (e.which == 3) || (e.which == 123) || (e.which == 83)) && isCtrl == true)
{
alert('Warning : Copyright is forbidden by the Administrator');
return false;
}
}
// right click code
var isNS = (navigator.appName == "Netscape") ? 1 : 0;
if(navigator.appName == "Netscape") document.captureEvents(Event.MOUSEDOWN||Event.MOUSEUP);
function mischandler(){
    alert('Warning : Copyright is forbidden by the Administrator');
return false;
}
function mousehandler(e){
var myevent = (isNS) ? e : event;
var eventbutton = (isNS) ? myevent.which : myevent.button;
if((eventbutton==2)||(eventbutton==3)) return false;
}
document.oncontextmenu = mischandler;
document.onmousedown = mousehandler;
document.onmouseup = mousehandler;
//select content code disable  alok goyal
function killCopy(e){
return false
}
function reEnable(){
return true
}
document.onselectstart=new Function ("return false")
if (window.sidebar){
document.onmousedown=killCopy
document.onclick=reEnable
}
</script>

document.addEventListener("contextmenu", function (e) {
  e.preventDefault();
});

var options = {
     enableAlert: true,
    alertText: "Mouse right click is disabled!"
}
<script src="disableMouseRightClick.js"></script>


var checker = function(){
        var state = {% if user.is_authenticated %}1{% else %}0{% endif %};
        if(state == 1){
            alert("you are logged in");
        }
    }
    var total_seconds = 1;

    setInterval(function(){
        checker();
    },total_seconds * 1000);